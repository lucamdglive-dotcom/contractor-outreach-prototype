# Contractor Outreach Prototype - Deployment Guide

This guide will walk you through deploying the contractor outreach prototype to GitHub and then to Vercel.

## Prerequisites

You'll need:
- A GitHub account (free at https://github.com)
- Git installed on your computer (https://git-scm.com/download)
- Your Vercel account (already set up)

## Step 1: Create a GitHub Repository

1. Go to https://github.com/new
2. Create a new repository with these settings:
   - **Repository name**: `contractor-outreach-prototype`
   - **Description**: `Automated contractor outreach landing page generator`
   - **Visibility**: Public (recommended for Vercel free tier)
   - Click **Create repository**

3. Copy the repository URL (it will look like `https://github.com/YOUR_USERNAME/contractor-outreach-prototype.git`)

## Step 2: Initialize Git and Push Code

Open your terminal/command prompt and run these commands:

```bash
# Navigate to the project directory
cd /path/to/contractor-outreach-prototype

# Initialize git (if not already done)
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: contractor outreach prototype with 10 sample businesses"

# Add the remote repository (replace with your URL from Step 1)
git remote add origin https://github.com/YOUR_USERNAME/contractor-outreach-prototype.git

# Push to GitHub
git branch -M main
git push -u origin main
```

## Step 3: Connect Vercel to GitHub

1. Go to https://vercel.com/new
2. Click **Import Project**
3. Paste your GitHub repository URL (from Step 1)
4. Click **Continue**
5. Vercel will ask for permissions to access your GitHub account—authorize it
6. Select the repository and click **Import**

## Step 4: Configure Vercel Deployment

1. **Project Name**: Keep as `contractor-outreach-prototype` (or customize)
2. **Framework Preset**: Select **React**
3. **Root Directory**: Leave as `./` (default)
4. **Environment Variables**: None needed for this prototype
5. Click **Deploy**

Vercel will now build and deploy your project. This takes 2-3 minutes.

## Step 5: Access Your Deployed Site

Once deployment is complete:
1. Vercel will give you a URL like `https://contractor-outreach-prototype.vercel.app`
2. Visit this URL to see your site with the default business data

## Step 6: Test with Sample Business Data

To test with a specific business, use the URL parameter format:

```
https://contractor-outreach-prototype.vercel.app/?data={encoded_json}
```

**Example URLs for each of the 10 businesses:**

1. **JDK Garden Services**
   ```
   https://contractor-outreach-prototype.vercel.app/?data=%7B%22name%22%3A%20%22JDK%20Garden%20Services%22%2C%20%22phone%22%3A%20%2207552%20501%20821%22%2C%20%22website%22%3A%20%22http%3A//jdkgardenservices.com/%22%2C%20%22rating%22%3A%205%2C%20%22reviews%22%3A%2014%2C%20%22address%22%3A%20%2225%20Ashford%20Ave%2C%20Worsley%2C%20Salford%20M28%201JJ%2C%20United%20Kingdom%22%2C%20%22gmb%22%3A%20%22JDK%20Garden%20Services%2C%2025%20Ashford%20Ave%2C%20Worsley%2C%20Salford%20M28%201JJ%2C%20United%20Kingdom%22%2C%20%22services%22%3A%20%22Garden%20Services%2C%20Landscaping%22%7D
   ```

2. **SWARB - Tree Surgeon**
   ```
   https://contractor-outreach-prototype.vercel.app/?data=%7B%22name%22%3A%20%22SWARB%20-%20Tree%20Surgeon%22%2C%20%22phone%22%3A%20%2207957%20470%20153%22%2C%20%22website%22%3A%20%22http%3A//www.swarb.org/%22%2C%20%22rating%22%3A%205%2C%20%22reviews%22%3A%2014%2C%20%22address%22%3A%20%2249%20Gorsemoor%20Rd%2C%20Cannock%20WS12%203HW%2C%20United%20Kingdom%22%2C%20%22gmb%22%3A%20%22SWARB%20-%20Tree%20Surgeon%2C%2049%20Gorsemoor%20Rd%2C%20Cannock%20WS12%203HW%2C%20United%20Kingdom%22%2C%20%22services%22%3A%20%22Tree%20Surgery%2C%20Landscaping%22%7D
   ```

(See `generated_sites.json` for all 10 URLs)

## Step 7: Create Subdomains (Optional)

To use custom subdomains instead of the main domain:

1. In Vercel, go to your project **Settings** → **Domains**
2. Add a custom domain (you'll need to own a domain)
3. Configure DNS records as Vercel instructs
4. Create subdomains for each business (e.g., `jdk-garden-services-01.yourdomain.com`)

For now, you can use the main Vercel URL and share it with businesses.

## Step 8: Share with Businesses

Once deployed, you can share the personalized URLs with each business via SMS or email. Each URL will render their specific business data.

---

## Troubleshooting

**Build fails during deployment?**
- Check that all dependencies are installed: `npm install` or `pnpm install`
- Ensure Node.js version is compatible (v18+)

**Site shows default data instead of business data?**
- Verify the URL parameter is properly encoded
- Check browser console for errors (F12 → Console tab)

**Need to update the code?**
- Make changes locally
- Commit and push: `git add . && git commit -m "Your message" && git push`
- Vercel will automatically redeploy

---

## Next Steps

Once verified, you can:
1. Scale to 20,000 businesses
2. Automate SMS delivery with GoHighLevel
3. Add analytics tracking to measure engagement
4. Create custom domains for each business

Need help? Let me know!
